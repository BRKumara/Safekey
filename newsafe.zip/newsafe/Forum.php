<!DOCTYPE html>
<html>
    <head>
        <title>SAFE KEY IOT Based Home Security System</title>
    <div w3-include-html="content.html"></div>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <!------ footer ---------->
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet" integrity="sha256-MfvZlkHCEqatNoGiOXveE8FIwMzZg4W85qfrfIFBfYc= sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">

    </head>

   <body style="background-color:white;">

        <div>

            <nav class="navbar navbar-dark bg-dark" style="opacity: 0.8;">
                <div style="color:white; position: absolute; left:1;" >
                    <h4>SAFE KEY -Forum Page</h4>
                </div>
            </nav>
        </div>
        </br>



    <center>

        <div class="w3-card-4" >
            <form>
                </br>


                <label for="description"> </label>
                <textarea  rows="6" cols="40"  class="description" name="description"  placeholder="Type Your Comment Here"></textarea>


                </br></br>

                <button class="w3-button w3-block w3-dark-grey" style= "">Post</button>

            </form>
        </div>

        <br>
        <br>
        <br>
        <div class="Vin6">

            <table class="t1"id="customers" style="color: blueviolet">
                <tr>
                    <th>Previous Question
                    <th>Date
                    <th>Name
                </tr>

                <tr>
                    <td>What is the company’s average response time to alarms?
                    <td>31/10/2018
                    <td>Vithujan
                </tr>
                <tr>
                    <td>How often does the home alarm company test their systems?
                    <td>31/10/2018
                    <td>Vithujan
                </tr>
                <tr>
                    <td>Is the company a member of a recognized security association?
                    <td>31/10/2018
                    <td>Vithujan
                </tr>
                <tr>
                    <td>Does the company offer systems with advanced safety features?
                    <td>31/10/2018
                    <td>Vithujan
                </tr>
            </table>
            <div>


                </center>


            </div>


            <style>

                .w3-card-4{
                    width:730px;
                    height:335px;
                    margin: auto; 
                    text-align: center;
                    border-radius: 5px;
                    opacity: 0.9; 
                }

                .w3-button{
                    border-radius: 5px;
                    float: right;
                }

                .description{
                    vertical-align: top; 
                    border-radius: 10px ;
                    border: 2px solid #609;
                    padding: 20px; 
                    width: 700px;
                    height: 300px; 
                }
                .footer {

                    left: 0;
                    bottom: 0;
                    width: 100%;
                    background-color: #000000;
                    color: white;
                    text-align: center;
                    opacity: 0.8;
                }
                B1{
                    width:80px;
                    color:white;
                    background-color:#4d94ff;
                    height:30px;
                    border-radius:10px;
                }

                body{

                    background-size:cover;
                }
                div.Vin{ 
                    position: absolute;
                    right:3%;
                    padding:5px;

                }

                div.Vin4{
                    position:absolute;
                    right:11%;
                    margin-top:20px;
                    font-size:20px;

                }
                div.Vin5{
                    background-color:gray;
                    padding: 40px 40px 40px;
                    padding-top:10px;
                    width:1100px;
                    border-radius:50px;
                    margin-top:50px;
                }

                #customers {
                    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                    border-collapse: collapse;
                    width: 100%;
                }

                #customers td, #customers th {
                    border: 1px solid #ddd;
                    padding: 8px;
                }

                #customers tr:nth-child(even){background-color: #f2f2f2;}

                #customers tr:hover {background-color: #ddd;}

                #customers th {
                    padding-top: 12px;
                    padding-bottom: 12px;
                    text-align: left;
                    background-color: gray;
                    color: white;
                }   

                .footer {

                    left: 0;
                    bottom: 0;
                    width: 100%;
                    background-color: #000000;
                    color: white;
                    text-align: center;
                    opacity: 0.8;

                }



            </style>

            <?php
            include 'Include_Footer.php';
            