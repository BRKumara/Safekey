<div class="footer">

    <nav class="w3-bar w3-gray">
        <a href="Index.php" class="w3-button w3-bar-item">Home</a>
        <a href="Forum.php" class="w3-button w3-bar-item">Forum</a>
        <a href="About_us.php" class="w3-button w3-bar-item">About Us</a>
        <a href="Contact.php" class="w3-button w3-bar-item">Contact Us</a>
    </nav>


    <div class="text-center center-block">


        <?php
        echo "<p>Copyright &copy; 2016-" . date("Y") . " www.safekey.com</p>";
        ?>
    </div>

    <style>


        .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: #000000;
            color: white;
            text-align: center;
            opacity: 0.8;

        }



    </style>

</div>
</body>
</html>